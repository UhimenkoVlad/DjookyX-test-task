let todoList = [];
let input = document.querySelector('.input');
let list = document.querySelector('.list');
let editBut = document.querySelector('.editButton');
let delBut = document.querySelector('.deleteButton');

if (localStorage.getItem('todo')) {
	todoList = JSON.parse(localStorage.getItem('todo'));

	displayMessages();
}

changeDisabled(editBut);
changeDisabled(delBut);

function addToDoList () {
	let todo = {
		todo: input.value,
		checked: false,
	};
	if (input.value) todoList.push(todo);
	input.value = '';

	displayMessages();
}

function editItemToDoList () {
	for (elem of todoList) {
		if (elem.checked) {
			let editEl = prompt('', elem.todo);
			if (editEl) elem.todo = editEl;
			elem.checked = false;
		}
	}
	editBut.disabled = true;
	delBut.disabled = true;


	displayMessages();
}

function delItemToDoList() {
	for (let i = 0; i < todoList.length; i++) {
		if (todoList[i].checked) {
			todoList.splice(i, 1);
			i--;
		}
	}
	editBut.disabled = true;
	delBut.disabled = true;

	displayMessages();
}

function displayMessages() {
	let displayMessage = '';
	todoList.forEach((elem, index) => {	
		let li = `
			<li>
				<div class='flex'>
					<input type="checkbox" id="${index}" ${elem.checked ? 'checked' : ''}>
					<label for="${index}">${elem.todo}</label>
				</div>
			</li>
		`;
		displayMessage += li;
	});

	list.innerHTML = displayMessage;
	localStorage.setItem('todo', JSON.stringify(todoList));
}

function changeDisabled(button) {
	button.disabled = (function () {
		for (elem of todoList) {
			if (elem.checked) {
				return false;
			}
		}
		return true;
	})();
}

list.addEventListener('change', function(event) {
	let elem = todoList[event.target.id];
	elem.checked = !elem.checked;

	changeDisabled(editBut);
	changeDisabled(delBut);

	localStorage.setItem('todo', JSON.stringify(todoList));
});

input.addEventListener('keyup', function(e) {
	if(e.which === 13){
  	addToDoList();
  }
})

function addNewElement (elem, arr) {
	arr.push(elem);
	for (let i = 0; i< arr.length -1; i++) {
		if (arr[i].todo == elem.todo) {
			arr.pop();
		}
	};
	console.log('arr', arr);
	return arr;
}
